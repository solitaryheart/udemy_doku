package pack;

public class Encap {
	
	private int balance;
	
	public void setBalance(int amount) {
		balance = amount+2;
	}
	
	public int getBalance() {
		return balance;
	}

}
