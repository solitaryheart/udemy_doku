package pack;

public class LivingBeing {

	public String eyes = "twoEyes";
	 public String legs = "running";
	
	 public void seeing() {
		System.out.println("Eyes is used to see, ");
	}
	
	 public void run() {
		System.out.println("Legs are used to run, parent class method");
	}
}
