package pack;

public class Logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean b1 = false;
		boolean b2 = true;
		
		System.out.println(b1&&b2);// && AND operator
		System.out.println(b1||b2);// || OR operator
		System.out.println(!b1); // ! NOT operator
		System.out.println(!b2);
		
		

	}

}
