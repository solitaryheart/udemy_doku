package pack;

public class Demon {

	public static void main(String[] args) {
			
		Encap encap = new Encap();
		
		encap.setBalance(20);
		System.out.println(encap.getBalance());

	}

}
