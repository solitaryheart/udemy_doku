package pack;

public class Arithmetic {

	public static void main(String[] args) {
		//Addition of two numbers
		int num1 = 4;
		int num2 = 5;
		int sum;
		int product;
		sum = num1 + num2; // Sum of the two numbers
		System.out.println("Sum of two numbers " + sum);
		
		// Multiplication
		product = num1 * num2;
		System.out.println("Prouduct of two number " + product);
		
		
		
		
	}

}
