package pack;

public class Lamp {
	
	boolean state = true;
	
	public void behaviour(){
		state  = false;
		
	}
	
	
	
	

}
