package pack;

public class Increment {

	public static void main(String[] args) {
		int num =2;
		//num = num+1;
		//num++;// Increment Operator
		num--;// Decrement Operator num = num-1;
		System.out.println(num);
		
		// num++ equivalent num = num+1;
		// num-- equivalent num = num-1;
	}

}
