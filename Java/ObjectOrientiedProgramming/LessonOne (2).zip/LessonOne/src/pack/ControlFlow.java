package pack;

public class ControlFlow {

	public static void main(String[] args) {
		// postive or not
		int a = 60; // greater than 100
		int b = -1;
		
		if(a<50) { // condition 1
			System.out.println("a is greater");	
			
		}else if(a<10) { // condition 2
			System.out.println("a is greater than 10");
			
		}
		
		System.out.println("End of program execution");
		
	}

}
