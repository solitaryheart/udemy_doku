package pack;

public class MyProgram {

	public static void main(String[] args) {
		//System.out.println("Hey, whats up");
		int number = 10;
		System.out.println(number);
		char a;
		a = 'o';
		System.out.println(a);
		float dec = 9.9f;
		System.out.println(dec);
		
		
		
	}

}//End of Program
