package pack;

public class Digits {

	public static void main(String[] args) {
		// Check the number of digits in the given number
		
		int number = 10;
		
		if(number>=0 && number<=9) {
			System.out.println("Single Digit Number");
			
		}else 
		
		System.out.println("Execution Ended");
		
		
	}

}
