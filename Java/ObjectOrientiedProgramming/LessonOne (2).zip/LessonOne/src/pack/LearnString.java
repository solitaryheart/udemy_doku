package pack;

public class LearnString {

	public static void main(String[] args) {
		
		
		String str = "Hello, how are you";
		
		String str2 = "how";	

		
		
		
		
		
		
		
		

	}

}
