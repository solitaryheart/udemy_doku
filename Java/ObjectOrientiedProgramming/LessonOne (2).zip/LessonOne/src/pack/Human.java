package pack;

public class Human {

	String eyes;
	String hands;
	String legs;
	
	
	void see() {
		System.out.println("i am seeing");
		
	}
	
	void pickup() {
		System.out.println("I am picking up with my hand");
	}
	
	void walk() {
		System.out.println("I am walking with my legs");
		
	}
	
	
	
}
