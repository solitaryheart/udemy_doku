package pack;

public class Demo {

	public static void main(String[] args) {
		
		System.out.println(6%2);
		
		String name = "Oliviaaa";

		switch(name) {
		
		case "Tom" : System.out.println(" Tom is taller");
		break;
		case "Frank": System.out.println(" Frank is fatter");
		break;
		case "Olivia": System.out.println(" Olivia is pretty");
		break;
		default: System.out.println("No names found matching");
		break;
		
		}
		
		System.out.println("Out of case statement");
	}

}
