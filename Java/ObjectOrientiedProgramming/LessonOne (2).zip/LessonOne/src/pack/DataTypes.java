package pack;

public class DataTypes {

	public static void main(String[] args) {
		int number = 10; //Integer/Number data Type
		float deci = 9.9f; // decimal number
		char character = 'A'; // Single letter
		boolean  bool = true; // boolean data types takes only true or false
		String sentence  = "I am learning JAVA ";
		String sentence2 = "Java is easy to learn";
		
		System.out.println(sentence +"-"+ sentence2);
		int sum = number+10;
		System.out.println("The sum of two numbers is:" + sum);
		//System.out.println(deci);
		//System.out.println(character);
		//System.out.println(bool);
		//System.out.println(sentence);
		
		

	}

}
