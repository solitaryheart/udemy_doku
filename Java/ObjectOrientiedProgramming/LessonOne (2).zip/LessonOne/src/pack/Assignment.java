package pack;

public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1;
		num1 = 5; //Assignment operator
		System.out.println(num1);
		int num2 = 4;
		System.out.println("Before Multiplication "+ num2);
		//num2 = num2 + num1;
		num2*=num1;
		System.out.println("After Multiplication " + num2);
		
		
		

	}

}
