package sup;

public class Child extends Parent {
	
	public Child() {
		System.out.println("I am in Child class constructor");
	}
	

	public static void main(String[] args) {
		Child child =  new Child();
		
	}

}
