package sup;

public class Parent {
	
	public Parent() {
		System.out.println("I am parent class construtor");
	}
	
	public Parent(String value) {
		System.out.println("I am parent class construtor" + value);
	}

}
