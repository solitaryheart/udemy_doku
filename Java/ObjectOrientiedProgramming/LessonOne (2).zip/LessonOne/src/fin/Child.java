package fin;

public class Child extends Parent {

}
