package fin;

public class Parent {
	
	 void method() {
		System.out.println("This is final method"); // This method cannot overriden
		
	}

}
