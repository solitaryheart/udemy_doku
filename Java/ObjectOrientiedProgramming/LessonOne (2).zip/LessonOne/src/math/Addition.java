package math;

public class Addition {

	 private int a = 10;
	 private int b = 15;
	
	  Addition() {
		 System.out.println("I am inside constructor");
	 }
	 
	 private void add() {
		
		System.out.println("I am inside Addition class");
		
	}
	 
	 public static void main(String[] args) {
		 
		 Addition addi = new Addition();
		 
	 }
	
}
