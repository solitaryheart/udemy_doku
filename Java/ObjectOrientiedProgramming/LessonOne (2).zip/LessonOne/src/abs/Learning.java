package abs;

public interface Learning {
	
	 int number = 99;
	
	public void method1();
	
	public void method2();
	

}
