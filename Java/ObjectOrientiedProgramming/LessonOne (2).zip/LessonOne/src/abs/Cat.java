package abs;

public class Cat extends Animal {

	@Override
	public void sound() {
		System.out.println("Cat meows");
		
	}

	
	
}
